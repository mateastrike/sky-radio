
module.exports = {
    BOT_TOKEN: process.env.BOT_TOKEN || 'MTQ2MjIzNDA5Nzk1MzgwNDM2MA.GZloh2.5xmhyWJWIva_XTMzqGDOc2bpsSdJ6ijA1WlYSA',
    CLIENT_ID: process.env.CLIENT_ID || '1462234097953804360',
    OWNER_ID: process.env.OWNER_ID || '819754930603556904',
    PREFIX: 's!',


    LAVALINK: {
        HOSTS: process.env.LAVALINK_HOSTS || 'pnode1.danbot.host',
        PORTS: process.env.LAVALINK_PORTS || '1186',
        PASSWORDS: process.env.LAVALINK_PASSWORDS || 'Kaun.Yuvraj ',
        SECURES: process.env.LAVALINK_SECURES || 'false'
    },


    MUSIC: {
        DEFAULT_PLATFORM: 'ytsearch',
        AUTOCOMPLETE_LIMIT: 5,
        PLAYLIST_LIMIT: 3,
        ARTWORK_STYLE: 'MusicCard' // 'Banner' for MediaGallery or 'MusicCard' for custom image card
    },


    SPOTIFY: {
        CLIENT_ID: process.env.SPOTIFY_CLIENT_ID || '3b677a5220694ee48b94c700051a2e84',
        CLIENT_SECRET: process.env.SPOTIFY_CLIENT_SECRET || 'a1b240053cf74d6aa114d6840e3730e2'
    },


    GENIUS: {
        API_KEY: process.env.GENIUS_API_KEY || ''
    }
};
